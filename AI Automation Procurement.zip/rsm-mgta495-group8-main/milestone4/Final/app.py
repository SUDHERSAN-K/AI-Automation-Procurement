import os
from shiny import App, ui, reactive, render
from shinywidgets import output_widget, render_widget
import pandas as pd
from ipydatagrid import DataGrid
from chatlas import ChatOpenAI
from dotenv import load_dotenv
from pydantic import BaseModel, Field
import requests
load_dotenv()

# Sidebar layout
app_ui = ui.page_sidebar(
    ui.sidebar(
        ui.h3("Navigation", style="color: #2c3e50; margin-bottom: 20px;"),
        ui.navset_pill(
            ui.nav_panel("Scope Identification", 
                ui.h4("Define Scope"),
                ui.tags.p("Upload and manage scope documents.")
            ),
            ui.nav_panel("RFQ Management", 
                ui.h4("RFQ Management"),
                ui.tags.p("Create and manage Requests for Quotation (RFQs).")
            ),
            ui.nav_panel("Bid Evaluation",
                ui.h4("Bid Evaluation"),
                ui.tags.p("Evaluate and compare vendor bids.")
            ),
            id="nav"
        ),
        ui.tags.hr(),
        ui.input_file("scope_file", "Choose Scope File (CSV)", accept=[".csv"]),
        ui.tags.hr(),
        style="background-color: #f8f9fa; padding: 15px; border-radius: 5px;",
        width=250
    ),
    ui.layout_column_wrap(
        ui.panel_well(
            ui.h4("Editable Table (from CSV)"),
            ui.div(
                {"class": "table-container"},
                output_widget("data_table")
            )
        ),
        ui.panel_well(
            ui.h4("Generated Email Preview"),
            ui.output_text("email_preview"),
            ui.input_action_button("accept_btn", "Accept"),
            ui.input_action_button("generate_btn", "Generate Email"),
            ui.input_action_button("copy_btn", "Copy Email")
        ),
        # Bottom Row - Research Helper
        ui.panel_well(
            ui.h4("Research Helper - Prompt"),
            ui.input_text_area("user_prompt", "Enter your prompt here:", rows=5),
            ui.input_action_button("submit_prompt", "Submit")
        ),
        ui.panel_well(
            ui.h4("Prompt Output"),
            ui.output_text("prompt_output")
        ),
        width=1/2
    ),
    title="Batched AI Procurement"
)


# LLM setup (copied from rfq_reference.py)
chat = ChatOpenAI(
    model="llama-3",
    api_key=os.getenv("LLAMA_API_KEY"),
    base_url="https://traip13.tgptinf.ucsd.edu/v1",
)

# Tool classes and registration (copied from rfq_reference.py)
class GetCurrentTemperature(BaseModel):
    latitude: float = Field(description="The latitude of the location. Must be a float.")
    longitude: float = Field(description="The longitude of the location. Must be a float.")

def get_current_temperature(latitude: float, longitude: float) -> dict:
    lat_lng = f"latitude={latitude}&longitude={longitude}"
    url = f"https://api.open-meteo.com/v1/forecast?{lat_lng}&current=temperature_2m,wind_speed_10m&hourly=temperature_2m,relative_humidity_2m,wind_speed_10m"
    response = requests.get(url)
    json = response.json()
    return json["current"]

class GetLatLong(BaseModel):
    location: str = Field(description="The location name to get latitude and longitude for. Must be a string.")

def get_lat_long(location: str) -> dict:
    url = f"https://geocode.maps.co/search?q='{location}'&api_key={os.getenv('GEO_API_KEY')}"
    response = requests.get(url)
    json = response.json()
    if len(json) == 0:
        raise ValueError(f"Could not find location: {location}. Try to determine the location from the LLM response and call this tool again with the new location.")
    else:
        return {"latitude": float(json[0]["lat"]), "longitude": float(json[0]["lon"])}

class GetNews(BaseModel):
    region: str = Field(description="The region to search news for. Must be a string. Example: 'Asia'")
    product: str = Field(description="The product to search news for. Must be a string. Example: 'steel'")

def get_news(region: str, product: str):
    news_key = os.getenv("news_key")
    query = f"{product} {region}"
    url = f"https://newsapi.org/v2/everything?q={query}&sortBy=publishedAt&pageSize=5&apiKey={news_key}"
    response = requests.get(url)
    if response.status_code != 200:
        raise Exception(f"Error: {response.status_code} - {response.text}")
    articles = response.json().get("articles", [])
    return [
        {"title": a["title"], "url": a["url"], "publishedAt": a["publishedAt"]}
        for a in articles
    ]

chat.register_tool(get_lat_long, model=GetLatLong)
chat.register_tool(get_current_temperature, model=GetCurrentTemperature)
chat.register_tool(get_news, model=GetNews)


def server(input, output, session):
    # Initialize navigation to RFQ Management
    @reactive.Effect
    def _():
        ui.update_navs("nav", selected="RFQ Management")
    
    df = reactive.Value(pd.DataFrame())

    @reactive.Effect
    @reactive.event(input.scope_file)
    def _():
        file_info = input.scope_file()
        if file_info is not None:
            df().drop(df().index, inplace=True)  # clear previous
            new_df = pd.read_csv(file_info[0]['datapath'])
            df.set(new_df)

    @output
    @render_widget
    def data_table():
        if df().empty:
            return ui.HTML("<div style='padding: 20px; color: #666;'>Upload a CSV file to see the data here.</div>")
        return DataGrid(df())

    @output
    @render.text
    def email_preview():
        return "Generated email will appear here after clicking 'Generate Email'."

    @output
    @render.text
    def prompt_output():
        # Only run when submit_prompt is pressed
        if not input.submit_prompt():
            return "Prompt output will show here."
        prompt = input.user_prompt()
        if not prompt:
            return "Prompt output will show here."
        try:
            response = chat.chat(prompt)
            if hasattr(response, 'content'):
                return response.content
            return str(response)
        except Exception as e:
            return f"Error from LLM: {e}"


app = App(app_ui, server)
