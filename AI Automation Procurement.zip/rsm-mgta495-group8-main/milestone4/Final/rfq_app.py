# %%
import os
from chatlas import ChatGoogle
from chatlas import ChatOpenAI
from dotenv import load_dotenv
from pydantic import BaseModel, Field
load_dotenv()

# %%
import pandas as pd

# %%
# chat = ChatOpenAI(model="gpt-4o-mini", api_key=os.getenv("OPENAI_API_KEY"))
chat = ChatOpenAI(
    model="llama-3",
    api_key=os.getenv("LLAMA_API_KEY"),
    base_url="https://traip13.tgptinf.ucsd.edu/v1",
)

# %% [markdown]
# 🌍 Tool Classes for Environmental Intelligence
# ---------------------------------------------
# Used to get:
# - Latitude & longitude from location names
# - Current temperature & wind speed from coordinates
# - Recent news articles based on product + region
# 
# Registered with the LLM so it can trigger them automatically.
# 

# %% [markdown]
# #### 🌡️ Tool implementation: Gets real-time weather and wind data from Open-Meteo based on coordinates
# 

# %%
class GetCurrentTemperature(BaseModel):
    """
    Get the current weather given a latitude and longitude.
    You MUST provide both latitude and longitude as numbers.
    If the user provides a location name (not latitude/longitude),
    you MUST first call the 'get_lat_long' tool to obtain the coordinates
    then call this tool with those coordinates.
    """

    latitude: float = Field(
        description="The latitude of the location. Must be a float."
    )
    longitude: float = Field(
        description="The longitude of the location. Must be a float."
    )

# %%
def get_current_temperature(latitude: float, longitude: float) -> dict:
    lat_lng = f"latitude={latitude}&longitude={longitude}"
    url = f"https://api.open-meteo.com/v1/forecast?{lat_lng}&current=temperature_2m,wind_speed_10m&hourly=temperature_2m,relative_humidity_2m,wind_speed_10m"
    response = requests.get(url)
    json = response.json()
    return json["current"]

# %% [markdown]
# #### 📍 Tool implementation: Converts a location name into latitude and longitude using maps.co
# 

# %%
class GetLatLong(BaseModel):
    """
    Use this tool to get the latitude and longitude for a location name provided by the user.
    If the user asks for weather and only provides a location name, call this tool first to get coordinates.
    """

    location: str = Field(
        description="The location name to get latitude and longitude for. Must be a string."
    )


# %%
def get_lat_long(location: str) -> dict:
    url = f"https://geocode.maps.co/search?q='{location}'&api_key={os.getenv('GEO_API_KEY')}"
    response = requests.get(url)
    json = response.json()
    if len(json) == 0:
        raise ValueError(
            f"Could not find location: {location}. Try to determine the location from the LLM response and call this tool again with the new location."
        )
    else:
        return {"latitude": float(json[0]["lat"]), "longitude": float(json[0]["lon"])}

# %% [markdown]
# #### 🌐 Tool implementation: Fetches recent news from NewsAPI based on region and product keyword
# 

# %%
class GetNews(BaseModel):
    """
    Use this tool to get recent news headlines related to a region and product.
    You MUST provide both a region (e.g., 'Asia') and a product (e.g., 'steel').
    This tool uses the NewsAPI.org service.
    """

    region: str = Field(
        description="The region to search news for. Must be a string. Example: 'Asia'"
    )
    product: str = Field(
        description="The product to search news for. Must be a string. Example: 'steel'"
    )

# %%
import requests
import os

news_key = os.getenv("news_key")

def get_news(region: str, product: str):
    """
    Get recent news headlines related to a region and product.
    """
    query = f"{product} {region}"
    url = f"https://newsapi.org/v2/everything?q={query}&sortBy=publishedAt&pageSize=5&apiKey={news_key}"

    response = requests.get(url)
    if response.status_code != 200:
        raise Exception(f"Error: {response.status_code} - {response.text}")
    
    articles = response.json().get("articles", [])
    return [
        {
            "title": a["title"],
            "url": a["url"],
            "publishedAt": a["publishedAt"]
        }
        for a in articles
    ]

# %%
chat.register_tool(get_lat_long, model=GetLatLong)
chat.register_tool(get_current_temperature, model=GetCurrentTemperature)
chat.register_tool(get_news, model=GetNews)


# %%
_ = chat.chat(
    "what is weather in beijing ",
)

# %%
_ = chat.chat(
    "We are planning to procure steel from asian market, tell me if theres is any geo politics mights affect our process, list the risk factors in bullet points"
)

# %% [markdown]
# 📋 Tool: Generate RFQ Pre-Evaluation Questions
# ----------------------------------------------
# LLM-based prompt to generate thoughtful, context-aware questions a procurement team
# should ask before sending an RFQ to a vendor. Includes logistics, risk, and compliance checks.


# %%
scope_doc = pd.read_csv("scope_document-RFQ.csv")

# %%
scope_doc

# %%
scope_doc.columns

# %% [markdown]
# AI-Based RFQ Email Generator
# ----------------------------
# 
# This script analyzes a scope document (CSV file), groups procurement items by vendor, 
# and uses a language model to generate tailored RFQ emails.
# 
# Steps:
# 1. Load and parse the scope_doc DataFrame.
# 2. Group items by vendor using a helper function.
# 3. Generate AI-powered professional RFQ emails per vendor.
# 4. If validation errors (e.g., missing certifications) exist, the AI includes a polite request.
# 

# %% [markdown]
# #### 🔧 Helper function to group items by vendor from the scope_doc DataFrame.
# #### It returns a dictionary with vendor names as keys and a list of their items as values.
# 

# %%
def prepare_vendor_item_summary(df):
    grouped = df.groupby("Recommended Vendor")
    vendor_data = {}

    for vendor, group_df in grouped:
        items = group_df.to_dict(orient="records")
        region = items[0].get("Region", "")
        vendor_data[vendor] = {
            "region": region,
            "items": items
        }

    return vendor_data


# %% [markdown]
# #### 🤖 Generates a complete RFQ email using AI for a specific vendor.
# #### It summarizes all items, delivery info, and appends a certification request if validation errors exist.
# #### The output is a ready-to-send email text.
# 

# %%
def generate_ai_email_for_vendor(vendor_name, region, items):
    item_descriptions = ""
    validation_summary = []

    for item in items:
        item_descriptions += (
            f"- {item['Item Name']}: {item['Specification']}, {item['Quantity']} {item['Unit of Measure']}, "
            f"Delivery by {item['Delivery Date']}\n"
        )
        if item.get("Validation Errors") and isinstance(item["Validation Errors"], str):
            validation_summary.append(item["Validation Errors"].strip())

    prompt = f"""
You are a procurement assistant.

Generate a professional RFQ email to the vendor named '{vendor_name}' located in {region}. 
The email should request a quotation for the following items:

{item_descriptions}

If any validation errors are mentioned, include a line requesting clarification or documentation.
Validation issues: {', '.join(set(validation_summary)) if validation_summary else 'None'}

Keep the tone polite and formal. Do not include prices—just a request for quotation, availability, and certifications.
Close the email professionally.
"""

    return chat.chat(prompt).content.strip()


# %% [markdown]
# #### 🔁 Main wrapper to iterate over all vendors and generate AI-driven emails.
# #### This combines the grouping logic and AI prompt generation in one pass.
# 

# %%
def generate_all_rfq_emails_ai(scope_doc):
    vendor_summary = prepare_vendor_item_summary(scope_doc)
    emails = {}

    for vendor, data in vendor_summary.items():
        email = generate_ai_email_for_vendor(vendor, data["region"], data["items"])
        emails[vendor] = email

    return emails


# %%
emails = generate_all_rfq_emails_ai(scope_doc)

for vendor, email in emails.items():
    print(f"\n📨 Email to: {vendor}\n{'='*80}\n{email}\n")

# %%



